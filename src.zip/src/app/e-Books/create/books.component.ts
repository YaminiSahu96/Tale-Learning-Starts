import {Component } from '@angular/core';


@Component({
  selector:'app-book-create',
  templateUrl:'books.component.html',
  styleUrls:['./books.component.css']
})

export class BooksCreateComponent{
  bind='';
  newReview=' ';
  onAddPost(bookInput:HTMLTextAreaElement)
  {
    console.dir(bookInput);
    //alert("review added");
    this.newReview=bookInput.value;
  }

}
